# Imports here
import matplotlib.pyplot as plt 

import argparse
import sys
import time
import json

import numpy as np
import torch
from torch import nn
from torch.nn import Sequential

from torchvision import datasets, transforms, models
from torch import optim
import torch.nn.functional as F

from PIL import Image
import Utils

from collections import OrderedDict

# TODO: Write a function that loads a checkpoint and rebuilds the model

parser = argparse.ArgumentParser(description= 'Testing')
parser.add_argument('--topk', type = int, default= 1, help='Top K most likely classes')
parser.add_argument('--file_path' , type = str, default ='checkpoint.pth', help= 'path to checkpoint file')
parser.add_argument('--path_to_image' , type = str, help= 'path to the image')
parser.add_argument('--category_names', type = str, default = 'cat_to_name.json', help= 'Mapping categories to real names')
parser.add_argument('--gpu', default = False, action='store_true', help='Use GPU for predicting')
    
args = parser.parse_args()

gpu= args.gpu

with open(args.category_names, 'r') as f:
    cat_to_name = json.load(f)
    
a= cat_to_name.values()

def load_checkpoint(filepath=args.file_path):
    checkpoint = torch.load(filepath)
    
    model = getattr(models, checkpoint['arch'])(pretrained=True)
    
    for param in model.parameters():
        param.requires_grad = False

    model.classifier = checkpoint['classifier']
    
    model.load_state_dict(checkpoint['state_dict'])
    
    model.optimizer = checkpoint['optimizer']
    
    model.class_to_idx = checkpoint['class_to_index']
    
    epochs = checkpoint['epochs']
    
    hidden_layers = checkpoint['hidden_layers']
    
    return model, epochs, hidden_layers

def predict(image_path, topk = args.topk):
    ''' Predict the class (or classes) of an image using a trained deep learning model.
    '''
    # TODO: Implement the code to predict the class from an image file
    image = Image.open(image_path)
    image = Utils.process_image(image)

    image = torch.from_numpy(image).type(torch.FloatTensor)
    image = image.unsqueeze(0)
    if torch.cuda.is_available() and gpu:
        image = image.cuda()
    
    model, _, _ = load_checkpoint(args.file_path)
    if torch.cuda.is_available() and gpu:
        model.cuda()
    with torch.no_grad():
        output= model.forward(image)
        prob = torch.exp(output)

    topk_prob = prob.topk(topk)
    
    probs = topk_prob[0]
    classes = topk_prob[1] 
    prediction = torch.max(prob.data,1)
    
    classes = classes.to('cpu').numpy().reshape(-1,)
    
    probs = probs.to('cpu')
    
    index_to_class = {val: key for key, val in model.class_to_idx.items()}
    top_classes = [index_to_class[each] for each in classes]
    y = top_classes
    d = [cat_to_name[i] for i in y]
    x = probs.detach().numpy().reshape(-1,)

    print('Top {} classes are {} with their probabilities {}'.format(args.topk, d, x))
    
image_path= args.path_to_image
model,_,_ = load_checkpoint(args.file_path)
predict(image_path)
