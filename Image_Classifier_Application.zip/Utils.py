import matplotlib.pyplot as plt 

import numpy as np
import torch
from torch import nn
from torch.nn import Sequential

from torchvision import datasets, transforms, models
from torch import optim
import torch.nn.functional as F

from collections import OrderedDict

def process_image(image):
    ''' Scales, crops, and normalizes a PIL image for a PyTorch model,
        returns an Numpy array
    '''
    
    # TODO: Process a PIL image for use in a PyTorch model
    width, height = image.size
    size = 256
    shortest_side = min(width, height)
    image = image.resize((int((width/shortest_side)*size), int((height/shortest_side)*size)))
    
    new_w = 224
    new_h = 224
    left = (width - new_w)/2
    top = (height - new_h)/2
    right = (width + new_w)/2
    bottom = (height + new_h)/2
    im = image.crop((left, top, right, bottom))
    
    np_image = np.array(im)
    np_image = np_image/255
    
    mean = np.array([0.485, 0.456, 0.406])
    std = np.array([0.229, 0.224, 0.225])
    np_image = (np_image - mean) / std

    return np_image.transpose((2,0,1))


def imshow(image, ax=None, title=None):
    if ax is None:
        fig, ax = plt.subplots()
    
    # PyTorch tensors assume the color channel is the first dimension
    # but matplotlib assumes is the third dimension
    image = image.transpose((1, 2, 0))
    
    # Undo preprocessing
    mean = np.array([0.485, 0.456, 0.406])
    std = np.array([0.229, 0.224, 0.225])
    image = std * image + mean
    
    # Image needs to be clipped between 0 and 1 or it looks like noise when displayed
    image = np.clip(image, 0, 1)
    
    ax.imshow(image)
    
    return ax