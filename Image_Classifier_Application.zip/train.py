# Imports here
import matplotlib.pyplot as plt 

import argparse
import sys
import time

import numpy as np
import torch
from torch import nn
from torch.nn import Sequential

from torchvision import datasets, transforms, models
from torch import optim
import torch.nn.functional as F

from collections import OrderedDict

import json

#Data directory
data_dir = 'flowers'

# Set up Parser
parser = argparse.ArgumentParser(description= 'Training')
parser.add_argument('--epochs', type = int, default= 6, help='Number of epochs in training')
parser.add_argument('--arch', type = str, default = 'vgg19', help= 'Set architecture of the network')
parser.add_argument('--hidden_layer1' , type= int, default= 4096, help= "Input the dimension for the first hidden layer")
parser.add_argument('--hidden_layer2' , type= int, default= 1000, help= "Input the dimension for the second hidden layer")
parser.add_argument('--hidden_layer3' , type= int, default= 512, help= "Input the dimension for the third hidden layer")
parser.add_argument('--learning_rate', type= float, default = 0.0008, help= 'Learning rate of deep network')
parser.add_argument('--data_directory', default = 'flowers', help='set data directory')
parser.add_argument('--save_dir', type = str , default='/home/workspace/aipnd-project', help=' set directory to save checkpoints')
parser.add_argument('--gpu', default = False, action='store_true', help='Use GPU for training')
    
args = parser.parse_args()

# Load the data
# TODO: Define your transforms for the training, validation, and testing sets


train_dir = args.data_directory +  '/train'
valid_dir = args.data_directory +  '/valid'
test_dir = args.data_directory +  '/test'

train_transforms = transforms.Compose([transforms.Resize(256),
                                       transforms.RandomResizedCrop(224),
                                      transforms.RandomRotation(degrees=20),
                                      transforms.ToTensor(),
                                      transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
                                      ])

test_transforms = transforms.Compose([transforms.Resize(256),
                                     transforms.CenterCrop(224),
                                      transforms.ToTensor(),
                                      transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
                                      ])


# TODO: Load the datasets with ImageFolder
image_datasets = datasets.ImageFolder(data_dir, transform= train_transforms)
train_images = datasets.ImageFolder(train_dir, transform= train_transforms)
valid_images = datasets.ImageFolder(valid_dir, transform= test_transforms)
test_images = datasets.ImageFolder(test_dir, transform= test_transforms)



# TODO: Using the image datasets and the trainforms, define the dataloaders
dataloaders = torch.utils.data.DataLoader(image_datasets, batch_size=32, shuffle=True)
trainloader = torch.utils.data.DataLoader(train_images, batch_size=32, shuffle=True)
validloader = torch.utils.data.DataLoader(valid_images, batch_size=32, shuffle=True)
testloader = torch.utils.data.DataLoader(test_images, batch_size=32, shuffle=True)


# Label mapping
with open('cat_to_name.json', 'r') as f:
    cat_to_name = json.load(f)
    
a = cat_to_name.values()

# TODO: Build and train your network
arch = args.arch

if arch== 'vgg19':
    model = models.vgg19(pretrained=True)
    
    input_size= 25088
    for param in model.parameters():
        param.requires_grad = False

    classifier = Sequential(OrderedDict([
                            ('fc1', nn.Linear(input_size, args.hidden_layer1)),
                            ('Relu1' , nn.ReLU(inplace=True)),
                            ('Dropout1', nn.Dropout(p=0.2)),
                            ('fc2', nn.Linear(args.hidden_layer1, args.hidden_layer2)),
                            ('Relu2', nn.ReLU(inplace=True)),
                            ('Dropout2', nn.Dropout(p=0.2)),
                            ('fc3', nn.Linear(args.hidden_layer2, args.hidden_layer3)),
                            ('Relu3', nn.ReLU(inplace=True)),
                            ('fc4', nn.Linear(args.hidden_layer3, len(a))),
                            ('output', nn.LogSoftmax(dim=1))
    ]))

if arch== 'vgg13':
    model = models.vgg13(pretrained=True)
    
    input_size= 25088
    for param in model.parameters():
        param.requires_grad = False

        classifier = Sequential(OrderedDict([
                            ('fc1', nn.Linear(input_size, args.hidden_layer1)),
                            ('Relu1' , nn.ReLU(inplace=True)),
                            ('Dropout1', nn.Dropout(p=0.2)),
                            ('fc2', nn.Linear(args.hidden_layer1, args.hidden_layer2)),
                            ('Relu2', nn.ReLU(inplace=True)),
                            ('Dropout2', nn.Dropout(p=0.2)),
                            ('fc3', nn.Linear(args.hidden_layer2, args.hidden_layer3)),
                            ('Relu3', nn.ReLU(inplace=True)),
                            ('fc4', nn.Linear(args.hidden_layer3, len(a))),
                            ('output', nn.LogSoftmax(dim=1))
    ]))
    
if arch== 'densenet161':
    model = models.densenet161(pretrained=True)
    input_size= 2208
    for param in model.parameters():
        param.requires_grad = False

    classifier = Sequential(OrderedDict([
                            ('fc1', nn.Linear(input_size, args.hidden_layer1)),
                            ('Relu1' , nn.ReLU(inplace=True)),
                            ('Dropout1', nn.Dropout(p=0.2)),
                            ('fc2', nn.Linear(args.hidden_layer1, args.hidden_layer2)),
                            ('Relu2', nn.ReLU(inplace=True)),
                            ('Dropout2', nn.Dropout(p=0.2)),
                            ('fc3', nn.Linear(args.hidden_layer2, args.hidden_layer3)),
                            ('Relu3', nn.ReLU(inplace=True)),
                            ('fc4', nn.Linear(args.hidden_layer3, len(a))),
                            ('output', nn.LogSoftmax(dim=1))
    ]))   
    
model.classifier = classifier
optimizer = optim.Adam(model.classifier.parameters(), lr=args.learning_rate)
criterion = nn.NLLLoss()

gpu= args.gpu

if torch.cuda.is_available() and gpu:
    model.to('cuda')

epochs= args.epochs
running_loss = 0 
running_loss_CV = 0
print_every = 40
step=0

step_CV = 0

size= correct = 0

for i in range(epochs):
    for images, labels in trainloader:

        step +=1
        
        if torch.cuda.is_available() and gpu:
            images, labels = images.to('cuda'), labels.to('cuda')
            model.cuda()
            
        optimizer.zero_grad()
        
        output = model.forward(images)
        loss = criterion(output, labels)

        loss.backward()
        optimizer.step()

        running_loss += loss.item()

        if step % print_every ==0:

            print('epochs: {}/{}'.format(i+1,epochs))
            print("Training loss is {:.4f}".format(running_loss/print_every))

            running_loss =0
            
    with torch.no_grad():
        for images, labels in validloader:
            
            step_CV +=1
            images, labels = images.to('cuda'), labels.to('cuda')
            output = model.forward(images)
            pred = torch.exp(output)
            prediction = torch.max(pred.data, 1)
            
            loss_CV = criterion(output, labels)
            running_loss_CV += loss_CV.item()

            correct += (prediction[1] == labels).sum().item()
            size += labels.size(0)
    
    print("Validation loss after epoch {} is {:.4f}".format(i+1, running_loss_CV/step_CV))
                
    running_loss_CV = 0
    step_CV = 0
    
    Validation_accuracy = 100* correct/size
    print('Validation accuracy is', 100* correct/size)
    correct = size = 0

# Training Accuracy
correct =0 
size =0
with torch.no_grad():
    for images, labels in trainloader:
        if torch.cuda.is_available() and gpu:
            images, labels = images.to('cuda'), labels.to('cuda')
        
        output = model.forward(images)
        pred = torch.exp(output)
        
        prediction = torch.max(pred.data, 1)
        
        correct += (prediction[1] == labels).sum().item()
        size += labels.size(0)
Training_accuracy = 100* correct/size
print('Training accuracy is', Training_accuracy)
   

# Validation accuracy
correct =0 
size =0
with torch.no_grad():
    for images, labels in validloader:
        if torch.cuda.is_available() and gpu:
            images, labels = images.to('cuda'), labels.to('cuda')
        
        output = model.forward(images)
        pred = torch.exp(output)
        
        prediction = torch.max(pred.data, 1)
        
        correct += (prediction[1] == labels).sum().item()
        size += labels.size(0)
    
Validation_accuracy = 100* correct/size    
print('Validation accuracy is', Validation_accuracy)


# TODO: Do validation on the test set
correct =0 
size =0

with torch.no_grad():
    for images, labels in testloader:
        if torch.cuda.is_available() and gpu:
            images, labels = images.cuda(), labels.cuda()

        output = model.forward(images)
        pred =  torch.exp(output)

        prediction = torch.max(pred.data, 1)

        correct += (prediction[1] == labels).sum().item()
        size += labels.size(0)
Test_accuracy = 100* correct/size
print('Test set accuracy is', Test_accuracy)


# SAVE THE CHECKPOINT
model.class_to_idx = train_images.class_to_idx

save_directory = args.save_dir
checkpoint = {'input_size': 25088,
              'output_size': 102,
              'hidden_layers': [args.hidden_layer1,args.hidden_layer2, args.hidden_layer3],
              'arch' : args.arch,
              'classifier' : classifier, 
              'optimizer': optimizer,
              'epochs' : epochs,
              'class_to_index' : train_images.class_to_idx,
              'state_dict': model.state_dict()}

torch.save(checkpoint, save_directory + '/checkpoint.pth')